<?php
// ============================================================
// ACTIVITY A - Data.php
// This replaces Database.php from Activity B. There is NO MySQL
// connection here at all — concert/ticket info is hardcoded in
// PHP arrays below, and anything that needs to "persist" while
// the user clicks around (account info, seat counts going down,
// bookings made) is kept in $_SESSION instead of a database table.
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['logged_in_user']);
}

function getCurrentUser() {
    return isLoggedIn() ? $_SESSION['logged_in_user'] : null;
}

function generateBookingCode() {
    return 'LANY-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
}

// ------------------------------------------------------------
// HARDCODED CATALOG (this is the stand-in for the "concerts" and
// "ticket_categories" tables from Activity B). It only gets seeded
// into the session once; after that, available_quantity is read
// from/written to the session copy so seat counts can go down
// when someone books, without ever touching a database.
// ------------------------------------------------------------
function seedConcerts() {
    return [
        [
            'id'          => 1,
            'title'       => 'LANY: a beautiful blur Tour',
            'venue'       => 'Mall of Asia Arena, Pasay City',
            'concert_date'=> '2026-08-14',
            'concert_time'=> '19:00:00',
            'description' => 'LANY returns to Manila for one night only, bringing the full a beautiful blur live experience to the Philippines.',
            'categories'  => [
                ['id' => 101, 'category_name' => 'General Admission', 'price' => 2500, 'available_quantity' => 1200],
                ['id' => 102, 'category_name' => 'VIP',               'price' => 5500, 'available_quantity' => 300],
                ['id' => 103, 'category_name' => 'Platinum',          'price' => 8500, 'available_quantity' => 80],
            ],
        ],
        [
            'id'          => 2,
            'title'       => 'LANY: Mama\'s Boy World Tour',
            'venue'       => 'SMX Convention Center, Pasay City',
            'concert_date'=> '2026-09-05',
            'concert_time'=> '20:00:00',
            'description' => 'An intimate run-through of LANY\'s catalog, from Malibu Nights to their newest singles.',
            'categories'  => [
                ['id' => 201, 'category_name' => 'General Admission', 'price' => 2200, 'available_quantity' => 900],
                ['id' => 202, 'category_name' => 'VIP',               'price' => 4800, 'available_quantity' => 250],
                ['id' => 203, 'category_name' => 'Platinum',          'price' => 7500, 'available_quantity' => 60],
            ],
        ],
        [
            'id'          => 3,
            'title'       => 'LANY: Unplugged Manila',
            'venue'       => 'New Frontier Theater, Quezon City',
            'concert_date'=> '2026-10-02',
            'concert_time'=> '19:30:00',
            'description' => 'A stripped-down acoustic evening with Paul Klein, just vocals, guitar, and the band.',
            'categories'  => [
                ['id' => 301, 'category_name' => 'General Admission', 'price' => 1800, 'available_quantity' => 600],
                ['id' => 302, 'category_name' => 'VIP',               'price' => 3500, 'available_quantity' => 150],
                ['id' => 303, 'category_name' => 'Platinum',          'price' => 6000, 'available_quantity' => 40],
            ],
        ],
    ];
}

// Makes sure the session has its own working copy of the catalog
// so quantities can change as bookings are made.
function initConcerts() {
    if (!isset($_SESSION['concerts'])) {
        $_SESSION['concerts'] = seedConcerts();
    }
}

// Returns every concert, with min/max price and total seats left
// computed on the fly (same numbers Activity B used to get from
// MIN()/MAX()/SUM() in SQL).
function getConcerts() {
    initConcerts();
    $concerts = $_SESSION['concerts'];

    foreach ($concerts as &$c) {
        $prices = array_column($c['categories'], 'price');
        $seats  = array_column($c['categories'], 'available_quantity');
        $c['min_price']  = min($prices);
        $c['max_price']  = max($prices);
        $c['seats_left'] = array_sum($seats);
    }
    unset($c);

    return $concerts;
}

// Returns one concert by id (mirrors "SELECT * FROM concerts WHERE id = ?").
function getConcertById($id) {
    initConcerts();
    foreach ($_SESSION['concerts'] as $c) {
        if ($c['id'] == $id) return $c;
    }
    return null;
}

// Finds a single ticket category inside a concert.
function getCategory($concertId, $categoryId) {
    $concert = getConcertById($concertId);
    if (!$concert) return null;
    foreach ($concert['categories'] as $cat) {
        if ($cat['id'] == $categoryId) return $cat;
    }
    return null;
}

// Decreases available_quantity for a category (mirrors the SQL
// "UPDATE ticket_categories SET available_quantity = available_quantity - ?").
function reduceAvailability($concertId, $categoryId, $qty) {
    foreach ($_SESSION['concerts'] as &$c) {
        if ($c['id'] == $concertId) {
            foreach ($c['categories'] as &$cat) {
                if ($cat['id'] == $categoryId) {
                    $cat['available_quantity'] -= $qty;
                }
            }
            unset($cat);
        }
    }
    unset($c);
}

// Saves a new booking for the currently logged-in user
// (mirrors "INSERT INTO bookings ...").
function addBooking($booking) {
    if (!isset($_SESSION['bookings'])) {
        $_SESSION['bookings'] = [];
    }
    $_SESSION['bookings'][] = $booking;
}

// Returns all bookings made by the current username
// (mirrors "SELECT * FROM bookings WHERE user_id = ?").
function getMyBookings() {
    if (!isLoggedIn() || !isset($_SESSION['bookings'])) return [];
    $username = $_SESSION['logged_in_user']['username'];
    return array_values(array_filter($_SESSION['bookings'], function ($b) use ($username) {
        return $b['username'] === $username;
    }));
}

function formatDate($d) { return date('D, M j, Y', strtotime($d)); }
function formatTime($t) { return date('g:i A', strtotime($t)); }
?>
