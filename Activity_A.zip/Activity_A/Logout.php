<?php
// ============================================================
// ACTIVITY A - Logout.php
// Same as Activity B's version, just requires Data.php instead
// of Database.php.
// ============================================================
require_once 'Data.php';

session_destroy();
header('Location: Login.php');
exit;
?>
